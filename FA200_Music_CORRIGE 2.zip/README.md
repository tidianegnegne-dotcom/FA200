# FA200 Music — version complète MVP

Cette version comprend une vraie base de données SQLite, une API Express, l'inscription/connexion, favoris, playlists, recherche, lecture audio et upload audio/cover pour un compte administrateur.

## Installation
1. Installer Node.js 18+.
2. Dans ce dossier : `npm install`
3. Définir `JWT_SECRET` et `ADMIN_EMAIL`.
4. Lancer : `npm start`
5. Ouvrir `http://localhost:3000`

## Production / Render
- Build command : `npm install`
- Start command : `npm start`
- Variables : `JWT_SECRET`, `ADMIN_EMAIL`
- Pour conserver SQLite/uploads sur un hébergement qui redémarre, utiliser un disque persistant ou migrer vers PostgreSQL + stockage objet.

## Important
Les fichiers audio de démonstration utilisent un son public de test. Pour une vraie plateforme, utiliser uniquement des fichiers pour lesquels FA200 dispose des droits/licences nécessaires.
